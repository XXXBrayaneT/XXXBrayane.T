Dit is een begeleidende presentatie bij het Sleutelboek Computernethardware 3.0. Deze presentatie mag vrij worden gebruikt, aangepast en verspreid. De laatste dia bevat de bronvermelding en moet ten allen tijde deel blijven uitmaken van de presentatie.

Om de presentatie correct weer te geven, is het noodzakelijk om het lettertype Barlow Condensed geïnstalleerd te hebben op je computer. Het lettertypebestand vind je in deze download. Meer uitleg over de manier waarop dit kan geïnstalleerd worden, vind je op https://support.microsoft.com/nl-nl/office/eigen-lettertypen-downloaden-en-installeren-om-met-office-te-gebruiken-0ee09e74-edc1-480c-81c2-5cf9537c70ce

Deze Powerpoint werd gemaakt in Microsoft Office 2016. Het is mogelijk dat bepaalde elementen niet helemaal correct worden weergegeven in andere versies van Microsoft Office.

Het doel van deze presentatie is om het lesgeven te ondersteunen. Daarom werd meer dan voorheen ingezet op visualisatie van de leerinhouden. Dit laat ook een meer interactieve vorm van lesgeven toe. Uiteraard staat het elke leerkracht vrij om de presentatie naar wens aan te passen voor de eigen lespraktijk.

De referenties naar de inhouden uit het Sleutelboek zijn te vinden in de notitieweergave van de presentatie.

Meer informatie over de Sleutelboeken is beschikbaar op www.sleutelboek.eu. Feedback over de Sleutelboeken of het bijhorende lesmateriaal kan gestuurd worden naar info@sleutelboek.eu en wordt zeer gewaardeerd.
